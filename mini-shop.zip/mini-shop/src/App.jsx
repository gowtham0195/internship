import { CartProvider } from "./context/CartContext";
import Navbar from "./components/Navbar";
import ProductList from "./components/ProductList";
import CartDrawer from "./components/CartDrawer";
import "./index.css";

function App() {
  return (
    <CartProvider>
      <Navbar />
      <ProductList />
      <CartDrawer />
    </CartProvider>
  );
}

export default App;