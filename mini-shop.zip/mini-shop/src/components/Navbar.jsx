import { useCart } from "../context/CartContext";

export default function Navbar() {
  const { state } = useCart();
  return (
    <nav className="bg-indigo-600 text-white p-4 flex justify-between">
      <h1 className="font-bold text-xl">Mini‑Shop</h1>
      <span className="font-medium">Cart: {state.items.length}</span>
    </nav>
  );
}