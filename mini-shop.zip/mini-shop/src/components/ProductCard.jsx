import { useCart } from "../context/CartContext";

export default function ProductCard({ product }) {
  const { dispatch } = useCart();
  return (
    <div className="border rounded-xl p-4 shadow-md">
      <img
        src={product.img}
        alt={product.name}
        className="w-full h-40 object-cover rounded-lg mb-2"
      />
      <h3 className="font-semibold">{product.name}</h3>
      <p className="text-sm text-gray-600 mb-2">${product.price}</p>
      <button
        onClick={() => dispatch({ type: "ADD", item: product })}
        className="bg-indigo-600 text-white w-full py-2 rounded-lg"
      >
        Add to cart
      </button>
    </div>
  );
}