import { useCart } from "../context/CartContext";

export default function CartDrawer() {
  const { state, dispatch } = useCart();
  return (
    <aside className="fixed right-2 top-20 bg-white shadow-lg p-4 w-60 rounded-xl border">
      <h2 className="font-bold mb-2">Your Cart</h2>
      {state.items.length === 0 && (
        <p className="text-sm">Cart is empty.</p>
      )}
      {state.items.map((item) => (
        <div key={item.id} className="flex justify-between items-center mb-2">
          <span>{item.name}</span>
          <button
            className="text-red-500"
            onClick={() => dispatch({ type: "REMOVE", id: item.id })}
          >
            ×
          </button>
        </div>
      ))}
    </aside>
  );
}