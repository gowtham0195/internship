export const products = [
  { id: 1, name: "T‑Shirt",  price: 19.99, img: "/img/shirt.jpg" },
  { id: 2, name: "Jeans",    price: 49.99, img: "/img/jeans.jpg" },
  { id: 3, name: "Sneakers", price: 89.99, img: "/img/shoes.jpg" },
];